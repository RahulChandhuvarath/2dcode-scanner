﻿
using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO.Ports;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;

namespace DataDecommision
{
    internal class BulkItemVM : INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler PropertyChanged;

        /// <summary>
        /// Method to call when the property value is changed
        /// </summary>
        /// <param name="propertyName"></param>
        /// 

        protected void NotifyPropertyChanged(string propertyName)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
        
       

        
        public BulkItemVM()
        {
            

            AllGLNs = GetGLNNames();
            if (AllGLNs.Count() > 0)
                SelectedGLN = AllGLNs[0];

            SelectedDate = null;
            ButtonScanClick = new ButtonCommandBinding(ButtonScan)
            {
                IsEnabled = true
            };
            ButtonNextClick = new ButtonCommandBinding(ButtonNext)
            {
                IsEnabled = true
            };
        }

        private string[] GetGLNNames()
        {
            string[] array = null;
            array = new string[2];
            array[0] = "123456";
            array[1] = "654321";
            
            
            return array;
        }

        private bool _isDateValid;
        public bool IsDateValid
        {
            get { return _isDateValid; }
            set { _isDateValid = value; NotifyPropertyChanged(nameof(IsDateValid)); }
        }

        private DateTime? _selectedDate;
        public DateTime? SelectedDate
        {
            get { return _selectedDate; }
            set
            {
                if (_selectedDate != value)
                {
                    _selectedDate = value;
                    NotifyPropertyChanged(nameof(SelectedDate));
                }
            }
        }

        private string selectedGLN;
        public string SelectedGLN
        {
            get { return selectedGLN; }
            set { selectedGLN = value; NotifyPropertyChanged("SelectedGLN"); }
        }


        private string[] allGLNs;
        public string[] AllGLNs
        {
            get { return allGLNs; }
            set { allGLNs = value; NotifyPropertyChanged("AllGLNs"); }
        }

        public ButtonCommandBinding ButtonScanClick { get; set; }
        public ButtonCommandBinding ButtonNextClick { get; set; }

        private string textSerial;
        public string TextSerial
        {
            get { return textSerial; }
            set { textSerial = value; NotifyPropertyChanged("TextSerial"); }
        }

        private string textGtin;
        public string TextGtin
        {
            get { return textGtin; }
            set { textGtin = value; NotifyPropertyChanged("TextGtin"); }
        }

        private string textNDC;
        public string TextNDC
        {
            get { return textNDC; }
            set { textNDC = value; NotifyPropertyChanged("TextNDC"); }
        }


        private string textBottle;
        public string TextBottle
        {
            get { return textBottle; }
            set { textBottle = value; NotifyPropertyChanged("TextBottle"); }
        }

        private string textCase;
        public string TextCase
        {
            get { return textCase; }
            set { textCase = value; NotifyPropertyChanged("TextCase"); }
        }

        private string textLot;
        public string TextLot
        {
            get { return textLot; }
            set { textLot = value; NotifyPropertyChanged("TextLot"); }
        }
        private string textPO;
        public string TextPO
        {
            get { return textPO; }
            set { textPO = value; NotifyPropertyChanged("TextPO"); }
        }
        private string textDelivery;
        public string TextDelivery
        {
            get { return textDelivery; }
            set { textDelivery = value; NotifyPropertyChanged("TextDelivery"); }
        }
        private string textZIPCode;
        public string TextZIPCode
        {
            get { return textZIPCode; }
            set { textZIPCode = value; NotifyPropertyChanged("TextZIPCode"); }
        }
         
        

        private string textEXP;
        public string TextEXP
        {
            get { return textEXP; }
            set { textEXP = value; NotifyPropertyChanged("TextEXP"); }
        }

        private bool scaningPopup;
        public bool ScaningPopup
        {
            get { return scaningPopup; }
            set { scaningPopup = value; NotifyPropertyChanged("ScaningPopup"); }
        }
        private async void ButtonScan()
        {
            Mouse.OverrideCursor = Cursors.Wait;
            ScaningPopup = true;

            await Task.Run(() =>
            {
               
                var code = ScannerDecoder.ScanAndDecode();
                TextGtin = code.Item1;
                TextLot = code.Item2;
                if (code.Item3 != null && code.Item3 != "")
                {
                    DateTime expResult = DateTime.ParseExact(20 + code.Item3, "yyyyMMdd", System.Globalization.CultureInfo.InvariantCulture);
                    SelectedDate = expResult;
                }
                else
                {
                    SelectedDate = null;
                }
                TextSerial = code.Item4;
               
            });
            Mouse.OverrideCursor = null;
            ScaningPopup = false;
        }
        public void ButtonNext()
        {
            if(SelectedDate == null)
            {
                MessageBox.Show("Not a Valid Date", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }
            if(TextLot == null || TextLot == "" || TextPO == null || TextPO == ""|| TextDelivery == null || TextDelivery == ""|| TextZIPCode == null || TextZIPCode == "" || TextBottle == null || TextBottle == ""  )
            {
                MessageBox.Show("Input in some fileds are missing", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }
            //if(TextNDC.Length != 12)
            //{
            //    MessageBox.Show("NDC should have 12 Characters including \"-\"", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            //    return;
            //}
            try
            {
                DecomData.BulkExp = ((DateTime)SelectedDate).ToString("yyyy-MM-dd");
                DecomData.BulkLot = TextLot;
                DecomData.BulkPO = TextPO;
                DecomData.BulkDelivery = TextDelivery;
                DecomData.BulkZIPCode = TextZIPCode;
                DecomData.BulkBottle = TextBottle;
            }
            catch { }

            NavigationService navigationService = (NavigationService)App.Current.MainWindow.Resources["NavigationService"];
            navigationService.CurrentPage = new ScanDisplayPage();
           // navigationService.CurrentPage = RePackingPage.Instance;
        }


    }
}
