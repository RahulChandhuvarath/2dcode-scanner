# 2dcode-scanner
Scan, Decode and Generate report
